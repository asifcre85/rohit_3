 
  order
  <?php /**PATH E:\wamp2\www\rohit\resources\views/Details.blade.php ENDPATH**/ ?>