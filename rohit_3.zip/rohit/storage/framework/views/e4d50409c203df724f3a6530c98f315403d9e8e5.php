 
  <h4><?php echo e($product->name); ?></h4>
  <?php /**PATH E:\wamp2\www\Laravel-6-Multi-Auth\resources\views/Details.blade.php ENDPATH**/ ?>