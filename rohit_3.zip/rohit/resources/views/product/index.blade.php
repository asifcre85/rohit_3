@extends('layouts.app')
@section('content')
<div align="center">
  <a href="{{ route('crud.create') }}" class="btn btn-success btn-sm">Add</a> 
</div>
<br />
@if ($message = Session::get('success'))
<div class="alert alert-success">
  <p>{{ $message }}</p>
</div>
@endif
<table class="table table-bordered table-striped">
 <tr> 
  <th>Image</th>
  <th>Category</th>
  <th>Name</th>
  <th>Code</th>
  <th>Stock</th>
  <th>Price</th>
  <th>Action</th>
 </tr>
 @foreach($data as $row)
  <tr>
   <td><img src="{{ URL::to('/') }}/images/{{ $row->image }}" class="img-thumbnail" width="75" /></td>
   <td>{{ $row->Category }}</td>
   <td>{{ $row->Name }}</td>
   <td>{{ $row->Code }}</td>
   <td>{{ $row->Stock }}</td>
   <td>{{ $row->Price }}</td>
   
   <td>
    <form action="{{ route('crud.destroy', $row->id) }}" method="post">
         
          <a href="{{ route('crud.edit', $row->id) }}" class="btn btn-warning">Edit</a>
          @csrf
          @method('DELETE')
          <button type="submit" onclick="return confirm('Are you sure?')" class="btn btn-danger">Delete</button>
    </form>
   </td>
  </tr>
 @endforeach
</table>
{!! $data->links() !!}
@endsection
