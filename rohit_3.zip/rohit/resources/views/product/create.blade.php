@extends('layouts.app')
@section('content')
@if($errors->any())
<div class="alert alert-danger">
 <ul>
  @foreach($errors->all() as $error)
  <li>{{ $error }}</li>
  @endforeach
 </ul>
</div>
@endif
<div align="right">
 <a href="{{ route('crud.index') }}" class="btn btn-primary">Back</a>
</div>

<form method="post" action="{{ route('crud.store') }}" enctype="multipart/form-data">

 @csrf
 <div class="form-group">
   
        <label class="col-md-4 text-left">Select Category:</label>
        <div class="col-md-8">
            <select name="Category" class="form-control input-lg" >
            <option value="Male">Male</option>
            <option value="Female">Female</option>
              </select>
        </div>

      <br/>
  <label class="col-md-4 text-left">Product Name:</label>
  <div class="col-md-8">
   <input type="text" name="Name" class="form-control input-lg" required />
   <input type="hidden" name="Code" class="form-control input-lg" />
  </div>
 
 <br />
 
 <div class="form-group">
  <label class="col-md-4 text-left">Stock:</label>
  <div class="col-md-8">
   <input type="text" name="Stock" class="form-control input-lg" required/>
  </div>
 </div>

 <br />
 <div class="form-group">
    <label class="col-md-4 text-left">Price:</label>
    <div class="col-md-8">
     <input type="text" name="Price" class="form-control input-lg" required/>
    </div>
   </div>

   <br />
 <div class="form-group">
  <label class="col-md-4 text-left">Select Profile Image:</label>
  <div class="col-md-8">
   <input type="file" name="image" />
  </div>
 </div>

 <br />
 <div class="form-group text-center">
  <input type="submit" name="add" class="btn btn-primary input-lg" value="Add" />
 </div>

</form>
@endsection