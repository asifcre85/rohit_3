<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Crud extends Model
{
    protected $fillable = [
        'Category', 'Name','Code', 'Stock','Price', 'image'
       ];

 //        public function o() {
 //  return $this->hasMany('App\Order','Name','name');                        
	// }
}
