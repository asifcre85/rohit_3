<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = [
        'name', 'quantity','total', 'email','order_id'
       ];

       public function c() {
  return $this->belongsTo('App\Crud','name','Name');                        
	}
	 public function u() {
  return $this->belongsTo('App\User','email','email');                        
	}

}
